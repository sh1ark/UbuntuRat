#!/bin/python
b = "\33[34;3m"
r = "\33[31;3m"
g="\33[32;3m"
y="\33[33;1m"
w = "\33[33;0m"
import os,time,sys
from subprocess import Popen,PIPE
os.system("clear")
print("""{}
        '||'  '||'          .|'''.|                               
         ||    ||   ....    ||..  '    ....    ....  
         ||''''||  '' .||    ''|||.  .|...|| .|       
         ||    ||  .|' ||  .     '|| ||      ||        
        .||.  .||. '|..'|' |'....|'   '|...'  '|...'  
	   {}
	    # # # # # # # # # # # # # # # # # #
	    #				      #
	    #    MeHdi Boullouf @ {}HaSec156{}    #
	    #				      #
	    # # # # # # # # # # # # # # # # # # 


""".format(g,b,r,b))
while True:
	try:
		sub = raw_input(w+'HaSec156@BuNTW  :')
		if "set lhost" in sub :
			lhost = sub.split()[-1]
			print(g+"[+] Set LHOST To {}".format(lhost))
		elif "set lport" in sub :
			lport = sub.split()[-1]
			print(g+'[+] Set Lport To {}'.format(lport))
		elif "set dir" in sub:
			die = sub.split()[-1]
			print(g+"[+] Set Dir To {}".format(die))
		elif "gen" in sub:
			print("[=] Detecting Values . . .")
			time.sleep(2)
			print(g+'[+] Set LHOST To {}\n[+] Set LPORT To{}\nSet Directory To {}'.format(lhost,lport,die))
			print(y+"Generating . . .")
			os.system("sh gen.sh {} {} {}".format(lhost,lport,die))
			time.sleep(2)
			print(g+'[+] Generated Succes ')
		elif "start" in sub:
			os.system('python2 listen.py {} {}'.format(lhost,lport))
		elif "exit" in sub:
			print(r+"[-] Exiting. . . !")
			time.sleep(2) 
			os.system("clear")
			sys.exit()
		elif "help" in sub:
			print("""
	[+] set lhost       :  PUT YOUR Ip   |e.g| set lhost <ip>
	[+] set lport       :  PUT YOUR port |e.g| set lport <port>
	[+] set dir         :  PUT YOUR DIR  |e.g| set dir <file.py>
	[+] gen             :  Start Generating
	[+] start           :  Start Exploitoing
 """)
		else:
			print('invalid choose !')
	except NameError as e:
		print(r+"[-] Set Values And Try Again .")
