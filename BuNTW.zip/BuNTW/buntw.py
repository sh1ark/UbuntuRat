#!/bin/python
import os
os.chdir("modules")
os.system("python2 ban.py")
